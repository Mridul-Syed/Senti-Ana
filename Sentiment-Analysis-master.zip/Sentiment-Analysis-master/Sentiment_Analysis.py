#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install pandas')
get_ipython().system('pip install tweepy')
get_ipython().system('pip install vaderSentiment')


# In[2]:


import tweepy
import pandas as pd
from nltk.sentiment.vader import SentimentIntensityAnalyzer


# In[3]:


#My Twitter API Authentication Variables
consumer_key = 'l1hhFh2NmbGAzMv7Id678uLnD'
consumer_secret = 'PJyGkMNKuy19tJcDj59j2P5eHIzPyhuTH68Youoj6Eu4Lbf9ze'
access_token = '885963743573590016-oNQ65dq0uazG8pd5MvvEatT2B0G0Cls'
access_token_secret = '5nt16wse4ZuGHRV5pYFsMsqJMcr1ATYM5PPrYMrfb8Jaa'


# In[4]:


auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)

tweets = api.search('Corona Virus', count=200)


data = pd.DataFrame(data=[tweet.text for tweet in tweets], columns=['Tweets'])

display(data.head(10))


print(tweets[0].created_at)


# In[5]:


import nltk
nltk.download('vader_lexicon')


# In[6]:


sid = SentimentIntensityAnalyzer()


listy = []

for index, row in data.iterrows():
  ss = sid.polarity_scores(row["Tweets"])
  listy.append(ss)
  
se = pd.Series(listy)
data['polarity'] = se.values

display(data.head(100))

