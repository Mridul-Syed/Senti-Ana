#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install newspaper3k


# In[ ]:


from textblob import TextBlob
import nltk 
from newspaper import Article


# In[ ]:


url = 'https://discuss.analyticsvidhya.com/t/sentiment-analysis-in-python-from-scratch/68023/2'
article = Article(url)


# In[5]:


article.download()
article.parse()
nltk.download('punkt')
article.nlp()


# In[6]:


text = article.summary

print(text)


# In[7]:


obj = TextBlob(text)

sentiment = obj.sentiment.polarity
print(sentiment)


# In[10]:


if sentiment == 0:
   print('Neutral')
elif sentiment > 0:
  print('Positive')
else:
  print('Negative')

